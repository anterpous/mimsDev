from transformers import Wav2Vec2FeatureExtractor


class CustomFeatureExtractor(Wav2Vec2FeatureExtractor):
    pass
